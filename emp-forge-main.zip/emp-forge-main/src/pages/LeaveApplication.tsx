import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { CalendarIcon, Clock, FileText } from "lucide-react";
import { format } from "date-fns";
import Header from "@/components/layout/Header";

const LeaveApplication = () => {
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [leaveType, setLeaveType] = useState("");
  const [reason, setReason] = useState("");

  const leaveHistory = [
    {
      id: "L001",
      type: "Annual Leave",
      startDate: "2024-01-15",
      endDate: "2024-01-20",
      days: 5,
      status: "Approved",
      reason: "Family vacation"
    },
    {
      id: "L002", 
      type: "Sick Leave",
      startDate: "2024-02-10",
      endDate: "2024-02-12",
      days: 2,
      status: "Approved",
      reason: "Medical appointment"
    },
    {
      id: "L003",
      type: "Annual Leave", 
      startDate: "2024-03-15",
      endDate: "2024-03-22",
      days: 7,
      status: "Pending",
      reason: "Spring vacation"
    }
  ];

  const getStatusBadge = (status: string) => {
    const variants = {
      'Approved': 'success',
      'Pending': 'warning',
      'Rejected': 'destructive'
    } as const;
    
    return (
      <Badge variant={variants[status as keyof typeof variants]} className="text-xs">
        {status}
      </Badge>
    );
  };

  return (
    <div className="flex-1 overflow-auto bg-background">
      <Header title="Leave Management" subtitle="Apply for leave and track your requests" />
      
      <div className="p-6 space-y-6">
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Leave Balance */}
          <Card className="shadow-enterprise border-border/50">
            <CardHeader className="border-b border-border bg-gradient-secondary/20">
              <CardTitle className="flex items-center space-x-2">
                <Clock className="h-5 w-5" />
                <span>Leave Balance</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Annual Leave</span>
                <span className="font-bold text-primary">18 days</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Sick Leave</span>
                <span className="font-bold text-accent">10 days</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Personal Leave</span>
                <span className="font-bold text-success">5 days</span>
              </div>
            </CardContent>
          </Card>

          {/* Apply Leave Form */}
          <Card className="lg:col-span-2 shadow-enterprise border-border/50">
            <CardHeader className="border-b border-border bg-gradient-secondary/20">
              <CardTitle className="flex items-center space-x-2">
                <FileText className="h-5 w-5" />
                <span>Apply for Leave</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <form className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="leave-type">Leave Type</Label>
                    <Select value={leaveType} onValueChange={setLeaveType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select leave type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="annual">Annual Leave</SelectItem>
                        <SelectItem value="sick">Sick Leave</SelectItem>
                        <SelectItem value="personal">Personal Leave</SelectItem>
                        <SelectItem value="maternity">Maternity Leave</SelectItem>
                        <SelectItem value="emergency">Emergency Leave</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Duration</Label>
                    <div className="flex space-x-2">
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="outline" className="flex-1 justify-start text-left font-normal">
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {startDate ? format(startDate, "PPP") : "Start date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar mode="single" selected={startDate} onSelect={setStartDate} />
                        </PopoverContent>
                      </Popover>

                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="outline" className="flex-1 justify-start text-left font-normal">
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {endDate ? format(endDate, "PPP") : "End date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar mode="single" selected={endDate} onSelect={setEndDate} />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reason">Reason</Label>
                  <Textarea
                    id="reason"
                    placeholder="Please provide reason for leave..."
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    className="min-h-20"
                  />
                </div>

                <Button className="w-full bg-gradient-primary hover:bg-primary-hover text-primary-foreground">
                  Submit Leave Application
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Leave History */}
        <Card className="shadow-enterprise border-border/50">
          <CardHeader className="border-b border-border bg-gradient-secondary/20">
            <CardTitle>Leave History</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="space-y-1">
              {leaveHistory.map((leave) => (
                <div key={leave.id} className="flex items-center justify-between p-4 hover:bg-muted/30 border-b border-border last:border-b-0">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{leave.type}</span>
                      <Badge variant="outline" className="text-xs">
                        {leave.days} days
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {leave.startDate} to {leave.endDate}
                    </p>
                    <p className="text-sm text-muted-foreground">{leave.reason}</p>
                  </div>
                  <div className="text-right space-y-2">
                    {getStatusBadge(leave.status)}
                    <p className="text-xs text-muted-foreground">{leave.id}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default LeaveApplication;