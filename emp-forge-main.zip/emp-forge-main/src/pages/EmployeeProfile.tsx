import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Building2, 
  Briefcase, 
  Calendar,
  DollarSign,
  Edit3,
  Save,
  X
} from "lucide-react";
import Header from "@/components/layout/Header";

const EmployeeProfile = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: "John Doe",
    email: "john.doe@company.com", 
    phone: "+1 (555) 123-4567",
    address: "123 Main St, New York, NY 10001",
    department: "Engineering",
    jobRole: "Senior Developer",
    employeeId: "EMP001",
    joinDate: "January 15, 2023",
    salary: "$95,000",
    manager: "Sarah Wilson"
  });

  const salaryHistory = [
    { date: "Jan 2024", amount: "$95,000", type: "Annual Increment" },
    { date: "Jan 2023", amount: "$85,000", type: "Promotion" },
    { date: "Jun 2022", amount: "$75,000", type: "Initial Salary" }
  ];

  const handleSave = () => {
    setIsEditing(false);
    // Here you would typically save to backend
  };

  const handleCancel = () => {
    setIsEditing(false);
    // Reset form data to original values
  };

  return (
    <div className="flex-1 overflow-auto bg-background">
      <Header title="Employee Profile" subtitle="Manage your personal information and view details" />
      
      <div className="p-6 space-y-6">
        {/* Profile Header */}
        <Card className="shadow-enterprise border-border/50">
          <CardHeader className="border-b border-border bg-gradient-secondary/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Avatar className="h-16 w-16">
                  <AvatarFallback className="bg-gradient-primary text-primary-foreground text-xl font-bold">
                    {formData.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="text-2xl font-bold text-foreground">{formData.name}</h2>
                  <p className="text-muted-foreground">{formData.jobRole}</p>
                  <Badge variant="outline" className="mt-1">
                    {formData.employeeId}
                  </Badge>
                </div>
              </div>
              
              {!isEditing ? (
                <Button 
                  onClick={() => setIsEditing(true)}
                  className="bg-gradient-primary hover:bg-primary-hover text-primary-foreground"
                >
                  <Edit3 className="mr-2 h-4 w-4" />
                  Edit Profile
                </Button>
              ) : (
                <div className="flex space-x-2">
                  <Button onClick={handleSave} size="sm" className="bg-gradient-accent">
                    <Save className="mr-2 h-4 w-4" />
                    Save
                  </Button>
                  <Button onClick={handleCancel} variant="outline" size="sm">
                    <X className="mr-2 h-4 w-4" />
                    Cancel
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
        </Card>

        <Tabs defaultValue="personal" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="personal">Personal Info</TabsTrigger>
            <TabsTrigger value="employment">Employment</TabsTrigger>
            <TabsTrigger value="salary">Salary History</TabsTrigger>
          </TabsList>

          {/* Personal Information */}
          <TabsContent value="personal">
            <Card className="shadow-enterprise border-border/50">
              <CardHeader className="border-b border-border bg-gradient-secondary/20">
                <CardTitle className="flex items-center space-x-2">
                  <User className="h-5 w-5" />
                  <span>Personal Information</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    {isEditing ? (
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                      />
                    ) : (
                      <div className="flex items-center space-x-2 p-3 bg-muted/30 rounded-md">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <span>{formData.name}</span>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    {isEditing ? (
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                      />
                    ) : (
                      <div className="flex items-center space-x-2 p-3 bg-muted/30 rounded-md">
                        <Mail className="h-4 w-4 text-muted-foreground" />
                        <span>{formData.email}</span>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    {isEditing ? (
                      <Input
                        id="phone"
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      />
                    ) : (
                      <div className="flex items-center space-x-2 p-3 bg-muted/30 rounded-md">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                        <span>{formData.phone}</span>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">Address</Label>
                    {isEditing ? (
                      <Input
                        id="address"
                        value={formData.address}
                        onChange={(e) => setFormData({...formData, address: e.target.value})}
                      />
                    ) : (
                      <div className="flex items-center space-x-2 p-3 bg-muted/30 rounded-md">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span>{formData.address}</span>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Employment Details */}
          <TabsContent value="employment">
            <Card className="shadow-enterprise border-border/50">
              <CardHeader className="border-b border-border bg-gradient-secondary/20">
                <CardTitle className="flex items-center space-x-2">
                  <Briefcase className="h-5 w-5" />
                  <span>Employment Details</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="grid gap-6 md:grid-cols-2">
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm text-muted-foreground">Department</Label>
                      <div className="flex items-center space-x-2 p-3 bg-muted/30 rounded-md mt-1">
                        <Building2 className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{formData.department}</span>
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm text-muted-foreground">Job Role</Label>
                      <div className="flex items-center space-x-2 p-3 bg-muted/30 rounded-md mt-1">
                        <Briefcase className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{formData.jobRole}</span>
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm text-muted-foreground">Employee ID</Label>
                      <div className="flex items-center space-x-2 p-3 bg-muted/30 rounded-md mt-1">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{formData.employeeId}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm text-muted-foreground">Join Date</Label>
                      <div className="flex items-center space-x-2 p-3 bg-muted/30 rounded-md mt-1">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{formData.joinDate}</span>
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm text-muted-foreground">Current Salary</Label>
                      <div className="flex items-center space-x-2 p-3 bg-muted/30 rounded-md mt-1">
                        <DollarSign className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium text-success">{formData.salary}</span>
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm text-muted-foreground">Reporting Manager</Label>
                      <div className="flex items-center space-x-2 p-3 bg-muted/30 rounded-md mt-1">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{formData.manager}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Salary History */}
          <TabsContent value="salary">
            <Card className="shadow-enterprise border-border/50">
              <CardHeader className="border-b border-border bg-gradient-secondary/20">
                <CardTitle className="flex items-center space-x-2">
                  <DollarSign className="h-5 w-5" />
                  <span>Salary History</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="space-y-1">
                  {salaryHistory.map((record, index) => (
                    <div key={index} className="flex items-center justify-between p-4 hover:bg-muted/30 border-b border-border last:border-b-0">
                      <div className="space-y-1">
                        <p className="font-medium">{record.date}</p>
                        <Badge variant="outline" className="text-xs">
                          {record.type}
                        </Badge>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-success">{record.amount}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default EmployeeProfile;