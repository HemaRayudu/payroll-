import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Building2, Users, Plus, Edit, Trash2, MapPin } from "lucide-react";
import Header from "@/components/layout/Header";

interface Department {
  id: string;
  name: string;
  description: string;
  manager: string;
  employeeCount: number;
  location: string;
  budget: string;
}

const DepartmentManagement = () => {
  const [departments, setDepartments] = useState<Department[]>([
    {
      id: "DEPT001",
      name: "Engineering",
      description: "Software development and technical operations",
      manager: "Sarah Wilson",
      employeeCount: 45,
      location: "New York",
      budget: "$2.5M"
    },
    {
      id: "DEPT002", 
      name: "Marketing",
      description: "Brand management and customer acquisition",
      manager: "Mike Johnson",
      employeeCount: 23,
      location: "Los Angeles", 
      budget: "$1.2M"
    },
    {
      id: "DEPT003",
      name: "Human Resources",
      description: "Employee relations and talent management",
      manager: "Lisa Chen",
      employeeCount: 12,
      location: "Chicago",
      budget: "$800K"
    },
    {
      id: "DEPT004",
      name: "Sales",
      description: "Revenue generation and client relationships",
      manager: "David Brown",
      employeeCount: 31,
      location: "Miami",
      budget: "$1.8M"
    }
  ]);

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newDepartment, setNewDepartment] = useState({
    name: "",
    description: "",
    manager: "",
    location: "",
    budget: ""
  });

  const handleAddDepartment = () => {
    const department: Department = {
      id: `DEPT${String(departments.length + 1).padStart(3, '0')}`,
      ...newDepartment,
      employeeCount: 0
    };
    setDepartments([...departments, department]);
    setNewDepartment({ name: "", description: "", manager: "", location: "", budget: "" });
    setIsAddDialogOpen(false);
  };

  const handleDeleteDepartment = (id: string) => {
    setDepartments(departments.filter(dept => dept.id !== id));
  };

  return (
    <div className="flex-1 overflow-auto bg-background">
      <Header title="Department Management" subtitle="Manage company departments and organizational structure" />
      
      <div className="p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid gap-6 md:grid-cols-4">
          <Card className="shadow-md border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Departments</p>
                  <p className="text-2xl font-bold">{departments.length}</p>
                </div>
                <Building2 className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-md border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Employees</p>
                  <p className="text-2xl font-bold">{departments.reduce((sum, dept) => sum + dept.employeeCount, 0)}</p>
                </div>
                <Users className="h-8 w-8 text-accent" />
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-md border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Avg Dept Size</p>
                  <p className="text-2xl font-bold">
                    {Math.round(departments.reduce((sum, dept) => sum + dept.employeeCount, 0) / departments.length)}
                  </p>
                </div>
                <Building2 className="h-8 w-8 text-success" />
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-md border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Locations</p>
                  <p className="text-2xl font-bold">
                    {new Set(departments.map(dept => dept.location)).size}
                  </p>
                </div>
                <MapPin className="h-8 w-8 text-warning" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Department Table */}
        <Card className="shadow-enterprise border-border/50">
          <CardHeader className="border-b border-border bg-gradient-secondary/20">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl font-bold">Departments</CardTitle>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-primary hover:bg-primary-hover text-primary-foreground">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Department
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>Add New Department</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="dept-name">Department Name</Label>
                      <Input
                        id="dept-name"
                        value={newDepartment.name}
                        onChange={(e) => setNewDepartment({...newDepartment, name: e.target.value})}
                        placeholder="Enter department name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="dept-desc">Description</Label>
                      <Input
                        id="dept-desc"
                        value={newDepartment.description}
                        onChange={(e) => setNewDepartment({...newDepartment, description: e.target.value})}
                        placeholder="Enter description"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="dept-manager">Manager</Label>
                      <Input
                        id="dept-manager"
                        value={newDepartment.manager}
                        onChange={(e) => setNewDepartment({...newDepartment, manager: e.target.value})}
                        placeholder="Enter manager name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="dept-location">Location</Label>
                      <Input
                        id="dept-location"
                        value={newDepartment.location}
                        onChange={(e) => setNewDepartment({...newDepartment, location: e.target.value})}
                        placeholder="Enter location"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="dept-budget">Budget</Label>
                      <Input
                        id="dept-budget"
                        value={newDepartment.budget}
                        onChange={(e) => setNewDepartment({...newDepartment, budget: e.target.value})}
                        placeholder="Enter budget (e.g., $1.5M)"
                      />
                    </div>
                    <Button onClick={handleAddDepartment} className="w-full bg-gradient-primary">
                      Add Department
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-muted/50">
                  <TableHead className="font-semibold">Department</TableHead>
                  <TableHead className="font-semibold">Manager</TableHead>
                  <TableHead className="font-semibold">Location</TableHead>
                  <TableHead className="font-semibold">Employees</TableHead>
                  <TableHead className="font-semibold">Budget</TableHead>
                  <TableHead className="font-semibold text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {departments.map((department) => (
                  <TableRow 
                    key={department.id} 
                    className="border-border hover:bg-muted/30 transition-colors"
                  >
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <Building2 className="h-4 w-4 text-primary" />
                          <span className="font-medium">{department.name}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">{department.description}</p>
                        <Badge variant="outline" className="text-xs">
                          {department.id}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{department.manager}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span>{department.location}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-sm">
                        {department.employeeCount} employees
                      </Badge>
                    </TableCell>
                    <TableCell className="font-semibold text-success">
                      {department.budget}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-end space-x-2">
                        <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-primary/20">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 hover:bg-destructive/20"
                          onClick={() => handleDeleteDepartment(department.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DepartmentManagement;