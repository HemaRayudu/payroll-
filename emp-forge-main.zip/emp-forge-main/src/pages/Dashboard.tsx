import { Users, DollarSign, Calendar, Building2, TrendingUp } from "lucide-react";
import Header from "@/components/layout/Header";
import StatsCard from "@/components/dashboard/StatsCard";
import EmployeeTable from "@/components/employees/EmployeeTable";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const Dashboard = () => {
  return (
    <div className="flex-1 overflow-auto bg-background">
      <Header 
        title="Dashboard Overview" 
        subtitle="Welcome back! Here's what's happening at your company."
      />
      
      <div className="p-6 space-y-6">
        {/* Stats Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <StatsCard
            title="Total Employees"
            value={247}
            change="+12 this month"
            changeType="positive"
            icon={Users}
            gradient="primary"
          />
          <StatsCard
            title="Monthly Payroll"
            value="$1.2M"
            change="+5.2%"
            changeType="positive"
            icon={DollarSign}
            gradient="accent"
          />
          <StatsCard
            title="Pending Leaves"
            value={8}
            change="-2 from yesterday"
            changeType="positive"
            icon={Calendar}
            gradient="secondary"
          />
          <StatsCard
            title="Departments"
            value={12}
            change="No change"
            changeType="neutral"
            icon={Building2}
            gradient="primary"
          />
        </div>

        {/* Quick Insights */}
        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-2 shadow-enterprise border-border/50">
            <CardHeader className="border-b border-border bg-gradient-secondary/20">
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5" />
                <span>Recent Activity</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center space-x-4 p-3 rounded-lg bg-muted/30">
                  <div className="h-2 w-2 rounded-full bg-success"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">New employee onboarded</p>
                    <p className="text-xs text-muted-foreground">Sarah Johnson joined Marketing team</p>
                  </div>
                  <span className="text-xs text-muted-foreground">2 hours ago</span>
                </div>
                <div className="flex items-center space-x-4 p-3 rounded-lg bg-muted/30">
                  <div className="h-2 w-2 rounded-full bg-warning"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Leave request pending</p>
                    <p className="text-xs text-muted-foreground">Mike Wilson submitted vacation request</p>
                  </div>
                  <span className="text-xs text-muted-foreground">4 hours ago</span>
                </div>
                <div className="flex items-center space-x-4 p-3 rounded-lg bg-muted/30">
                  <div className="h-2 w-2 rounded-full bg-accent"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Payroll processed</p>
                    <p className="text-xs text-muted-foreground">November payroll completed successfully</p>
                  </div>
                  <span className="text-xs text-muted-foreground">1 day ago</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-enterprise border-border/50">
            <CardHeader className="border-b border-border bg-gradient-secondary/20">
              <CardTitle>Department Summary</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Engineering</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-primary w-3/4"></div>
                    </div>
                    <span className="text-sm font-medium">45</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Marketing</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-accent w-1/2"></div>
                    </div>
                    <span className="text-sm font-medium">23</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">HR</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-success w-1/4"></div>
                    </div>
                    <span className="text-sm font-medium">12</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Sales</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-warning w-2/3"></div>
                    </div>
                    <span className="text-sm font-medium">31</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Employee Table */}
        <EmployeeTable />
      </div>
    </div>
  );
};

export default Dashboard;