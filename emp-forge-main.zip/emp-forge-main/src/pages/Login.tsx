import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building2, Lock, Mail, Eye, EyeOff } from "lucide-react";

interface LoginProps {
  onLogin: (role: 'admin' | 'employee') => void;
}

const Login = ({ onLogin }: LoginProps) => {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock login logic - in real app, this would validate against backend
    const role = email.includes('admin') ? 'admin' : 'employee';
    onLogin(role);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-secondary p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Logo */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="h-16 w-16 rounded-2xl bg-gradient-primary flex items-center justify-center shadow-enterprise">
              <Building2 className="h-8 w-8 text-primary-foreground" />
            </div>
          </div>
          <div>
            <h1 className="text-3xl font-bold text-foreground">EmpForge</h1>
            <p className="text-muted-foreground">Employee Management System</p>
          </div>
        </div>

        {/* Login Card */}
        <Card className="shadow-enterprise border-border/50">
          <CardHeader className="space-y-1 text-center border-b border-border bg-gradient-secondary/20">
            <CardTitle className="text-2xl font-bold">Welcome Back</CardTitle>
            <CardDescription>Sign in to your account to continue</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium">Email Address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="john.doe@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10 h-12"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10 h-12"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-2 top-1/2 h-8 w-8 -translate-y-1/2"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>

              <Button 
                type="submit" 
                className="w-full h-12 bg-gradient-primary hover:bg-primary-hover text-primary-foreground font-medium shadow-md hover:shadow-lg transition-all duration-200"
              >
                Sign In
              </Button>
            </form>

            {/* Demo Accounts */}
            <div className="space-y-3 border-t border-border pt-6">
              <p className="text-sm text-muted-foreground text-center">Demo Accounts</p>
              <div className="grid gap-2">
                <Button
                  variant="outline"
                  onClick={() => onLogin('admin')}
                  className="w-full justify-between hover:bg-primary/5"
                >
                  <span>Admin Dashboard</span>
                  <Badge variant="default" className="text-xs">Admin</Badge>
                </Button>
                <Button
                  variant="outline"
                  onClick={() => onLogin('employee')}
                  className="w-full justify-between hover:bg-accent/5"
                >
                  <span>Employee Portal</span>
                  <Badge variant="secondary" className="text-xs">Employee</Badge>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-muted-foreground">
          © 2024 EmpForge. All rights reserved.
        </p>
      </div>
    </div>
  );
};

export default Login;