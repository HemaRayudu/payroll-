import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Briefcase, DollarSign, Plus, Edit, Trash2, TrendingUp } from "lucide-react";
import Header from "@/components/layout/Header";

interface JobRole {
  id: string;
  title: string;
  department: string;
  baseSalary: number;
  minSalary: number;
  maxSalary: number;
  level: string;
  requirements: string[];
  employeeCount: number;
}

const JobRoleManagement = () => {
  const [jobRoles, setJobRoles] = useState<JobRole[]>([
    {
      id: "JOB001",
      title: "Senior Software Developer",
      department: "Engineering",
      baseSalary: 95000,
      minSalary: 85000,
      maxSalary: 110000,
      level: "Senior",
      requirements: ["5+ years experience", "React/Node.js", "Team leadership"],
      employeeCount: 12
    },
    {
      id: "JOB002",
      title: "Marketing Manager",
      department: "Marketing", 
      baseSalary: 85000,
      minSalary: 75000,
      maxSalary: 95000,
      level: "Manager",
      requirements: ["3+ years marketing", "Digital marketing", "Analytics"],
      employeeCount: 5
    },
    {
      id: "JOB003",
      title: "HR Specialist",
      department: "Human Resources",
      baseSalary: 65000,
      minSalary: 55000,
      maxSalary: 75000,
      level: "Mid-level",
      requirements: ["HR certification", "2+ years experience", "HRIS knowledge"],
      employeeCount: 3
    },
    {
      id: "JOB004",
      title: "Sales Representative",
      department: "Sales",
      baseSalary: 55000,
      minSalary: 45000,
      maxSalary: 70000,
      level: "Entry-level",
      requirements: ["Sales experience", "CRM proficiency", "Communication skills"],
      employeeCount: 15
    }
  ]);

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newJobRole, setNewJobRole] = useState({
    title: "",
    department: "",
    baseSalary: "",
    minSalary: "",
    maxSalary: "",
    level: "",
    requirements: ""
  });

  const departments = ["Engineering", "Marketing", "Human Resources", "Sales", "Finance", "Operations"];
  const levels = ["Entry-level", "Mid-level", "Senior", "Manager", "Director", "Executive"];

  const handleAddJobRole = () => {
    const jobRole: JobRole = {
      id: `JOB${String(jobRoles.length + 1).padStart(3, '0')}`,
      title: newJobRole.title,
      department: newJobRole.department,
      baseSalary: parseInt(newJobRole.baseSalary),
      minSalary: parseInt(newJobRole.minSalary),
      maxSalary: parseInt(newJobRole.maxSalary),
      level: newJobRole.level,
      requirements: newJobRole.requirements.split(',').map(req => req.trim()),
      employeeCount: 0
    };
    setJobRoles([...jobRoles, jobRole]);
    setNewJobRole({
      title: "",
      department: "",
      baseSalary: "",
      minSalary: "",
      maxSalary: "",
      level: "",
      requirements: ""
    });
    setIsAddDialogOpen(false);
  };

  const handleDeleteJobRole = (id: string) => {
    setJobRoles(jobRoles.filter(role => role.id !== id));
  };

  const getLevelBadge = (level: string) => {
    const variants = {
      'Entry-level': 'secondary',
      'Mid-level': 'default',
      'Senior': 'success', 
      'Manager': 'warning',
      'Director': 'destructive',
      'Executive': 'destructive'
    } as const;
    
    return (
      <Badge variant={variants[level as keyof typeof variants]} className="text-xs">
        {level}
      </Badge>
    );
  };

  return (
    <div className="flex-1 overflow-auto bg-background">
      <Header title="Job Role Management" subtitle="Define and manage job positions across the organization" />
      
      <div className="p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid gap-6 md:grid-cols-4">
          <Card className="shadow-md border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Job Roles</p>
                  <p className="text-2xl font-bold">{jobRoles.length}</p>
                </div>
                <Briefcase className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-md border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Avg Base Salary</p>
                  <p className="text-2xl font-bold">
                    ${Math.round(jobRoles.reduce((sum, role) => sum + role.baseSalary, 0) / jobRoles.length / 1000)}K
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-success" />
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-md border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Highest Salary</p>
                  <p className="text-2xl font-bold">
                    ${Math.max(...jobRoles.map(role => role.maxSalary)) / 1000}K
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-accent" />
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-md border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Filled Positions</p>
                  <p className="text-2xl font-bold">
                    {jobRoles.reduce((sum, role) => sum + role.employeeCount, 0)}
                  </p>
                </div>
                <Briefcase className="h-8 w-8 text-warning" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Job Roles Table */}
        <Card className="shadow-enterprise border-border/50">
          <CardHeader className="border-b border-border bg-gradient-secondary/20">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl font-bold">Job Roles</CardTitle>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-primary hover:bg-primary-hover text-primary-foreground">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Job Role
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add New Job Role</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="job-title">Job Title</Label>
                      <Input
                        id="job-title"
                        value={newJobRole.title}
                        onChange={(e) => setNewJobRole({...newJobRole, title: e.target.value})}
                        placeholder="Enter job title"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="job-department">Department</Label>
                      <Select value={newJobRole.department} onValueChange={(value) => setNewJobRole({...newJobRole, department: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                        <SelectContent>
                          {departments.map(dept => (
                            <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="job-level">Level</Label>
                      <Select value={newJobRole.level} onValueChange={(value) => setNewJobRole({...newJobRole, level: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select level" />
                        </SelectTrigger>
                        <SelectContent>
                          {levels.map(level => (
                            <SelectItem key={level} value={level}>{level}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid gap-4 grid-cols-3">
                      <div className="space-y-2">
                        <Label htmlFor="min-salary">Min Salary</Label>
                        <Input
                          id="min-salary"
                          type="number"
                          value={newJobRole.minSalary}
                          onChange={(e) => setNewJobRole({...newJobRole, minSalary: e.target.value})}
                          placeholder="45000"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="base-salary">Base Salary</Label>
                        <Input
                          id="base-salary"
                          type="number"
                          value={newJobRole.baseSalary}
                          onChange={(e) => setNewJobRole({...newJobRole, baseSalary: e.target.value})}
                          placeholder="55000"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="max-salary">Max Salary</Label>
                        <Input
                          id="max-salary"
                          type="number"
                          value={newJobRole.maxSalary}
                          onChange={(e) => setNewJobRole({...newJobRole, maxSalary: e.target.value})}
                          placeholder="70000"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="requirements">Requirements (comma-separated)</Label>
                      <Input
                        id="requirements"
                        value={newJobRole.requirements}
                        onChange={(e) => setNewJobRole({...newJobRole, requirements: e.target.value})}
                        placeholder="Experience, Skills, Certifications"
                      />
                    </div>

                    <Button onClick={handleAddJobRole} className="w-full bg-gradient-primary">
                      Add Job Role
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-muted/50">
                  <TableHead className="font-semibold">Job Title</TableHead>
                  <TableHead className="font-semibold">Department</TableHead>
                  <TableHead className="font-semibold">Level</TableHead>
                  <TableHead className="font-semibold">Salary Range</TableHead>
                  <TableHead className="font-semibold">Employees</TableHead>
                  <TableHead className="font-semibold text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {jobRoles.map((role) => (
                  <TableRow 
                    key={role.id} 
                    className="border-border hover:bg-muted/30 transition-colors"
                  >
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <Briefcase className="h-4 w-4 text-primary" />
                          <span className="font-medium">{role.title}</span>
                        </div>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {role.requirements.slice(0, 2).map((req, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {req}
                            </Badge>
                          ))}
                          {role.requirements.length > 2 && (
                            <Badge variant="outline" className="text-xs">
                              +{role.requirements.length - 2} more
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">{role.id}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-xs">
                        {role.department}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {getLevelBadge(role.level)}
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <p className="font-semibold text-success">
                          ${role.baseSalary.toLocaleString()}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          ${role.minSalary.toLocaleString()} - ${role.maxSalary.toLocaleString()}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-sm">
                        {role.employeeCount} hired
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-end space-x-2">
                        <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-primary/20">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 hover:bg-destructive/20"
                          onClick={() => handleDeleteJobRole(role.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default JobRoleManagement;