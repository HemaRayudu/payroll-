import { useState } from "react";
import Login from "./Login";
import Dashboard from "./Dashboard";
import Sidebar from "@/components/layout/Sidebar";

const Index = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState<'admin' | 'employee'>('admin');

  const handleLogin = (role: 'admin' | 'employee') => {
    setUserRole(role);
    setIsLoggedIn(true);
  };

  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar userRole={userRole} />
      <Dashboard />
    </div>
  );
};

export default Index;
