import { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface StatsCardProps {
  title: string;
  value: string | number;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  icon: LucideIcon;
  gradient?: 'primary' | 'accent' | 'secondary';
}

const StatsCard = ({ 
  title, 
  value, 
  change, 
  changeType = 'neutral', 
  icon: Icon,
  gradient = 'primary'
}: StatsCardProps) => {
  const gradientClasses = {
    primary: 'bg-gradient-primary',
    accent: 'bg-gradient-accent', 
    secondary: 'bg-gradient-secondary'
  };

  const changeColors = {
    positive: 'text-success',
    negative: 'text-destructive',
    neutral: 'text-muted-foreground'
  };

  return (
    <Card className="relative overflow-hidden border-border/50 shadow-md hover:shadow-lg transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
              {title}
            </p>
            <div className="flex items-baseline space-x-2">
              <p className="text-3xl font-bold text-foreground">{value}</p>
              {change && (
                <Badge 
                  variant="outline" 
                  className={`text-xs ${changeColors[changeType]}`}
                >
                  {change}
                </Badge>
              )}
            </div>
          </div>
          
          <div className={`h-12 w-12 rounded-xl ${gradientClasses[gradient]} flex items-center justify-center shadow-lg`}>
            <Icon className="h-6 w-6 text-primary-foreground" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default StatsCard;