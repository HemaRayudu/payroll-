import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Edit, Trash2, Eye, Mail, Phone } from "lucide-react";

interface Employee {
  id: string;
  name: string;
  email: string;
  phone: string;
  department: string;
  jobRole: string;
  salary: number;
  status: 'Active' | 'Inactive' | 'On Leave';
  joinDate: string;
}

const mockEmployees: Employee[] = [
  {
    id: "EMP001",
    name: "John Doe",
    email: "john.doe@company.com",
    phone: "+1 (555) 123-4567",
    department: "Engineering",
    jobRole: "Senior Developer",
    salary: 95000,
    status: "Active",
    joinDate: "2023-01-15"
  },
  {
    id: "EMP002",
    name: "Sarah Wilson",
    email: "sarah.wilson@company.com",
    phone: "+1 (555) 987-6543",
    department: "HR",
    jobRole: "HR Manager",
    salary: 85000,
    status: "Active",
    joinDate: "2022-11-03"
  },
  {
    id: "EMP003",
    name: "Mike Johnson",
    email: "mike.johnson@company.com",
    phone: "+1 (555) 456-7890",
    department: "Marketing",
    jobRole: "Marketing Specialist",
    salary: 65000,
    status: "On Leave",
    joinDate: "2023-03-20"
  }
];

const EmployeeTable = () => {
  const getStatusBadge = (status: Employee['status']) => {
    const variants = {
      'Active': 'success',
      'Inactive': 'destructive', 
      'On Leave': 'warning'
    } as const;
    
    return (
      <Badge variant={variants[status]} className="text-xs">
        {status}
      </Badge>
    );
  };

  return (
    <Card className="shadow-enterprise border-border/50">
      <CardHeader className="border-b border-border bg-gradient-secondary/20">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold text-foreground">Employee Management</CardTitle>
          <Button className="bg-gradient-primary hover:bg-primary-hover text-primary-foreground">
            Add Employee
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-muted/50">
              <TableHead className="font-semibold text-foreground">Employee</TableHead>
              <TableHead className="font-semibold text-foreground">Contact</TableHead>
              <TableHead className="font-semibold text-foreground">Department</TableHead>
              <TableHead className="font-semibold text-foreground">Job Role</TableHead>
              <TableHead className="font-semibold text-foreground">Salary</TableHead>
              <TableHead className="font-semibold text-foreground">Status</TableHead>
              <TableHead className="font-semibold text-foreground text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mockEmployees.map((employee) => (
              <TableRow 
                key={employee.id} 
                className="border-border hover:bg-muted/30 transition-colors"
              >
                <TableCell>
                  <div className="space-y-1">
                    <p className="font-medium text-foreground">{employee.name}</p>
                    <p className="text-sm text-muted-foreground">{employee.id}</p>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="space-y-1">
                    <div className="flex items-center space-x-1">
                      <Mail className="h-3 w-3 text-muted-foreground" />
                      <span className="text-sm">{employee.email}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Phone className="h-3 w-3 text-muted-foreground" />
                      <span className="text-sm">{employee.phone}</span>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="text-xs">
                    {employee.department}
                  </Badge>
                </TableCell>
                <TableCell className="font-medium">{employee.jobRole}</TableCell>
                <TableCell className="font-semibold text-success">
                  ${employee.salary.toLocaleString()}
                </TableCell>
                <TableCell>{getStatusBadge(employee.status)}</TableCell>
                <TableCell>
                  <div className="flex items-center justify-end space-x-2">
                    <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-accent/20">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-primary/20">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-destructive/20">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default EmployeeTable;