import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  UserCheck, 
  Building2, 
  Briefcase, 
  DollarSign, 
  Calendar,
  Settings,
  LogOut,
  BarChart3,
  FileText
} from "lucide-react";

interface SidebarProps {
  userRole: 'admin' | 'employee';
  className?: string;
}

const Sidebar = ({ userRole, className }: SidebarProps) => {
  const adminMenuItems = [
    { icon: BarChart3, label: "Dashboard", href: "/dashboard", badge: null },
    { icon: Users, label: "Employees", href: "/employees", badge: "12" },
    { icon: Building2, label: "Departments", href: "/departments", badge: null },
    { icon: Briefcase, label: "Job Roles", href: "/job-roles", badge: null },
    { icon: DollarSign, label: "Payroll", href: "/payroll", badge: "New" },
    { icon: Calendar, label: "Leave Requests", href: "/leave-requests", badge: "3" },
    { icon: FileText, label: "Reports", href: "/reports", badge: null },
    { icon: Settings, label: "Settings", href: "/settings", badge: null },
  ];

  const employeeMenuItems = [
    { icon: UserCheck, label: "My Profile", href: "/profile", badge: null },
    { icon: Calendar, label: "Apply Leave", href: "/apply-leave", badge: null },
    { icon: FileText, label: "Leave History", href: "/leave-history", badge: null },
    { icon: DollarSign, label: "Salary History", href: "/salary-history", badge: null },
  ];

  const menuItems = userRole === 'admin' ? adminMenuItems : employeeMenuItems;

  return (
    <div className={cn(
      "flex h-screen w-64 flex-col bg-card border-r border-border shadow-enterprise",
      className
    )}>
      {/* Logo */}
      <div className="flex h-16 items-center border-b border-border px-6">
        <div className="flex items-center space-x-3">
          <div className="h-8 w-8 rounded-lg bg-gradient-primary flex items-center justify-center">
            <Building2 className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">EmpForge</h1>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">
              {userRole === 'admin' ? 'Admin Panel' : 'Employee Portal'}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-2 p-4">
        {menuItems.map((item) => (
          <Button
            key={item.href}
            variant="ghost"
            className="w-full justify-start h-12 px-4 text-left hover:bg-secondary/50 hover:text-secondary-foreground transition-all duration-200"
          >
            <item.icon className="mr-3 h-5 w-5" />
            <span className="flex-1">{item.label}</span>
            {item.badge && (
              <Badge 
                variant={item.badge === "New" ? "default" : "secondary"}
                className="ml-auto text-xs"
              >
                {item.badge}
              </Badge>
            )}
          </Button>
        ))}
      </nav>

      {/* User Section */}
      <div className="border-t border-border p-4">
        <div className="flex items-center space-x-3 mb-4">
          <div className="h-10 w-10 rounded-full bg-gradient-accent flex items-center justify-center">
            <UserCheck className="h-5 w-5 text-accent-foreground" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate">
              {userRole === 'admin' ? 'Admin User' : 'John Doe'}
            </p>
            <p className="text-xs text-muted-foreground">
              {userRole === 'admin' ? 'System Administrator' : 'Software Developer'}
            </p>
          </div>
        </div>
        <Button 
          variant="outline" 
          className="w-full h-10 justify-start text-muted-foreground hover:text-destructive hover:border-destructive/20"
        >
          <LogOut className="mr-2 h-4 w-4" />
          Sign Out
        </Button>
      </div>
    </div>
  );
};

export default Sidebar;