# Payroll Management Backend (Complete, No Lombok)

## Overview
Complete backend for Payroll Management System: entities, repos, services, controllers, JWT, Flyway migrations, Swagger UI.

## Quick start
1. Create MySQL DB:
   > CREATE DATABASE payroll_db;
2. Update `src/main/resources/application.properties` with DB creds and JWT secret.
3. Build and run:
   > mvn clean install
   > mvn spring-boot:run
4. Swagger UI:
   > http://localhost:8080/swagger-ui/index.html
5. Seeded admin user: username `admin`, password `admin123` (bcrypt-hashed in V2 migration)

## Notes
- If Hibernate validation fails set `spring.jpa.hibernate.ddl-auto` to `update` for testing, but use `validate` for production.
- The `my pay` endpoint is a placeholder; will be implemented when frontend identifies employee via JWT principal.
