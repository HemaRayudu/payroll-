package com.payroll.controller;
import com.payroll.dto.LoginRequestDto;
import com.payroll.dto.LoginResponseDto;
import com.payroll.service.AuthService; 
import com.payroll.repository.UserRepository; 
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*; 
import java.util.Map;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {
    private final AuthService authService; 
    private final UserRepository userRepo;
    private final PasswordEncoder encoder;
    public AuthController(AuthService authService, UserRepository userRepo, PasswordEncoder encoder){ 
    	this.authService = authService;
    	this.userRepo = userRepo; 
    	this.encoder = encoder; 
    	}
    
    @PostMapping("/login") 
    public ResponseEntity<LoginResponseDto> login(@RequestBody LoginRequestDto req){ 
    	return ResponseEntity.ok(authService.login(req)); 
    	}
    @PostMapping("/bootstrap-admin") 
    public ResponseEntity<?> bootstrapAdmin(@RequestParam String username, @RequestParam String password, @RequestParam String email){
    	if (userRepo.existsByUsername(username)) return ResponseEntity.badRequest().body(Map.of("error","exists")); 
    	com.payroll.domain.User user = new com.payroll.domain.User(username, encoder.encode(password), email, com.payroll.domain.Role.ADMIN, true); 
    	userRepo.save(user); 
    	return ResponseEntity.ok(Map.of("created", username)); 
    	}
}
