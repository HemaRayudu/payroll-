package com.payroll.controller;
import com.payroll.domain.Department; import com.payroll.domain.Job; import com.payroll.repository.DepartmentRepository; import com.payroll.repository.JobRepository; import org.springframework.http.HttpStatus; import org.springframework.http.ResponseEntity; import org.springframework.security.access.prepost.PreAuthorize; import org.springframework.web.bind.annotation.*; import jakarta.validation.Valid;
@RestController @RequestMapping("/api/v1") @PreAuthorize("hasRole('ADMIN')") public class DepartmentJobController {
    private final DepartmentRepository deptRepo; private final JobRepository jobRepo;
    public DepartmentJobController(DepartmentRepository deptRepo, JobRepository jobRepo){ this.deptRepo = deptRepo; this.jobRepo = jobRepo; }
    @GetMapping("/departments") public ResponseEntity<?> listDepartments(){ return ResponseEntity.ok(deptRepo.findAll()); }
    @PostMapping("/departments") public ResponseEntity<?> createDepartment(@RequestBody @Valid Department d){ return ResponseEntity.status(HttpStatus.CREATED).body(deptRepo.save(d)); }
    @PutMapping("/departments/{id}") public ResponseEntity<?> updateDepartment(@PathVariable Long id, @RequestBody @Valid Department d){ d.setId(id); return ResponseEntity.ok(deptRepo.save(d)); }
    @DeleteMapping("/departments/{id}") public ResponseEntity<?> deleteDepartment(@PathVariable Long id){ deptRepo.deleteById(id); return ResponseEntity.noContent().build(); }
    @GetMapping("/jobs") public ResponseEntity<?> listJobs(){ return ResponseEntity.ok(jobRepo.findAll()); }
    @PostMapping("/jobs") public ResponseEntity<?> createJob(@RequestBody @Valid Job j){ return ResponseEntity.status(HttpStatus.CREATED).body(jobRepo.save(j)); }
    @PutMapping("/jobs/{id}") public ResponseEntity<?> updateJob(@PathVariable Long id, @RequestBody @Valid Job j){ j.setId(id); return ResponseEntity.ok(jobRepo.save(j)); }
    @DeleteMapping("/jobs/{id}") public ResponseEntity<?> deleteJob(@PathVariable Long id){ jobRepo.deleteById(id); return ResponseEntity.noContent().build(); }
}
