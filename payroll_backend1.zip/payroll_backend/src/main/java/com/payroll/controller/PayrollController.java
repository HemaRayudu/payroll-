package com.payroll.controller;
import com.payroll.domain.PayrollItem; import com.payroll.domain.PayrollRun; import com.payroll.repository.PayrollRunRepository; import com.payroll.service.PayrollService; import org.springframework.http.HttpStatus; import org.springframework.http.ResponseEntity; import org.springframework.security.access.prepost.PreAuthorize; import org.springframework.web.bind.annotation.*; import java.util.List; import java.util.Map;
@RestController @RequestMapping("/api/v1/payroll") public class PayrollController {
    private final PayrollService payrollService; private final PayrollRunRepository runRepo;
    public PayrollController(PayrollService payrollService, PayrollRunRepository runRepo){ this.payrollService = payrollService; this.runRepo = runRepo; }
    @PostMapping("/runs") @PreAuthorize("hasRole('ADMIN')") public ResponseEntity<PayrollRun> createRun(@RequestParam int year, @RequestParam int month){ return ResponseEntity.status(HttpStatus.CREATED).body(payrollService.createRun(year, month)); }
    @PostMapping("/runs/{id}/process") @PreAuthorize("hasRole('ADMIN')") public ResponseEntity<PayrollRun> process(@PathVariable Long id){ return ResponseEntity.ok(payrollService.processRun(id)); }
    @PostMapping("/runs/{id}/lock") @PreAuthorize("hasRole('ADMIN')") public ResponseEntity<PayrollRun> lock(@PathVariable Long id){ return ResponseEntity.ok(payrollService.lockRun(id)); }
    @GetMapping("/runs/{id}/items") @PreAuthorize("hasRole('ADMIN')") public ResponseEntity<List<PayrollItem>> items(@PathVariable Long id){ return ResponseEntity.ok(payrollService.items(id)); }
    @GetMapping("/my/{year}/{month}") public ResponseEntity<?> myPay(){ return ResponseEntity.ok(Map.of("message","Implement employee-specific lookup based on Principal")); }
}
