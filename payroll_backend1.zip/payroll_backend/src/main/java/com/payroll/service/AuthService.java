package com.payroll.service;
import com.payroll.domain.User; 
import com.payroll.dto.LoginRequestDto; 
import com.payroll.dto.LoginResponseDto; 
import com.payroll.repository.UserRepository; 
import com.payroll.security.JwtService; 
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken; 
import org.springframework.security.crypto.password.PasswordEncoder; 
import org.springframework.stereotype.Service;
import java.util.Map;

@Service 
public class AuthService {
    private final AuthenticationManager authManager; 
    private final JwtService jwtService; 
    private final UserRepository userRepo; 
    private final PasswordEncoder encoder;
    public AuthService(AuthenticationManager authManager, JwtService jwtService, UserRepository userRepo, PasswordEncoder encoder){ 
    	this.authManager = authManager; 
    	this.jwtService = jwtService; 
    	this.userRepo = userRepo; 
    	this.encoder = encoder; 
    	}
    
    public LoginResponseDto login(LoginRequestDto req){
    	authManager.authenticate(new UsernamePasswordAuthenticationToken(req.getUsername(), req.getPassword()));
    	User user = userRepo.findByUsername(req.getUsername()).orElseThrow(); 
    	String token = jwtService.generateToken(user.getUsername(), Map.of("role", user.getRole().name(), "uid", user.getId()));
    	com.payroll.dto.AuthUser au = new com.payroll.dto.AuthUser(user.getId(), user.getUsername(), user.getRole());
    	LoginResponseDto resp = new LoginResponseDto();
    	resp.setAccessToken(token);
    	resp.setUser(au);
    	return resp;
    	}
}
