package com.payroll.dto;

public class LoginResponseDto {
	private String accessToken; 
    private AuthUser user;
    
    public LoginResponseDto(){}
    
    public String getAccessToken(){ 
    	return accessToken;
    	} 
    
    public void setAccessToken(String accessToken){ 
    	this.accessToken = accessToken; 
    	}
    
    public AuthUser getUser(){ 
    	return user; 
    	} 
    
    public void setUser(AuthUser user){ 
    	this.user = user; 
    	}
}
