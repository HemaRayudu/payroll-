package com.payroll.domain;
import jakarta.persistence.*;
import java.math.BigDecimal;
@Entity @Table(name="jobs")
public class Job {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable=false, unique=true) private String title;
    @Column(nullable=false, precision=12, scale=2) private BigDecimal baseSalary;
    public Job() {}
    public Job(String title, BigDecimal baseSalary){ this.title = title; this.baseSalary = baseSalary; }
    public Long getId(){ return id; } public void setId(Long id){ this.id = id; }
    public String getTitle(){ return title; } public void setTitle(String title){ this.title = title; }
    public BigDecimal getBaseSalary(){ return baseSalary; } public void setBaseSalary(BigDecimal baseSalary){ this.baseSalary = baseSalary; }
}
