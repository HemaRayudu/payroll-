package com.payroll.domain;
public enum Role { ADMIN, EMPLOYEE }
