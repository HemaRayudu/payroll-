package com.payroll.domain;
import jakarta.persistence.*;
import java.util.List;
@Entity @Table(name="payroll_runs")
public class PayrollRun {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable=false) private int year;
    @Column(nullable=false) private int month;
    @Column(nullable=false) private boolean locked = false;
    @OneToMany(mappedBy = "run", cascade = CascadeType.ALL) private List<PayrollItem> items;
    public PayrollRun() {}
    public Long getId(){ return id; } public void setId(Long id){ this.id = id; }
    public int getYear(){ return year; } public void setYear(int year){ this.year = year; }
    public int getMonth(){ return month; } public void setMonth(int month){ this.month = month; }
    public boolean isLocked(){ return locked; } public void setLocked(boolean locked){ this.locked = locked; }
    public List<PayrollItem> getItems(){ return items; } public void setItems(List<PayrollItem> items){ this.items = items; }
}
