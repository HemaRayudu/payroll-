package com.payroll.domain;
import jakarta.persistence.*;
import java.time.LocalDate;
@Entity @Table(name="leave_requests")
public class LeaveRequest {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional=false) @JoinColumn(name="employee_id") private Employee employee;
    @Column(nullable=false) private LocalDate startDate;
    @Column(nullable=false) private LocalDate endDate;
    @Column(nullable=false) private String leaveType;
    @Enumerated(EnumType.STRING) @Column(nullable=false, length=20) private Status status = Status.PENDING;
    public enum Status { PENDING, APPROVED, REJECTED }
    public LeaveRequest() {}
    public Long getId(){ return id; } public void setId(Long id){ this.id = id; }
    public Employee getEmployee(){ return employee; } public void setEmployee(Employee employee){ this.employee = employee; }
    public LocalDate getStartDate(){ return startDate; } public void setStartDate(LocalDate startDate){ this.startDate = startDate; }
    public LocalDate getEndDate(){ return endDate; } public void setEndDate(LocalDate endDate){ this.endDate = endDate; }
    public String getLeaveType(){ return leaveType; } public void setLeaveType(String leaveType){ this.leaveType = leaveType; }
    public Status getStatus(){ return status; } public void setStatus(Status status){ this.status = status; }
}
