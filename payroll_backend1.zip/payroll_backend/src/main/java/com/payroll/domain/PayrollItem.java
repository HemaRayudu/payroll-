package com.payroll.domain;
import jakarta.persistence.*;
import java.math.BigDecimal;
@Entity @Table(name="payroll_items", uniqueConstraints = @UniqueConstraint(name="uk_run_employee", columnNames = {"run_id","employee_id"}))
public class PayrollItem {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional=false) @JoinColumn(name="run_id") private PayrollRun run;
    @ManyToOne(optional=false) @JoinColumn(name="employee_id") private Employee employee;
    @Column(nullable=false, precision=12, scale=2) private BigDecimal gross;
    @Column(nullable=false, precision=12, scale=2) private BigDecimal deductions;
    @Column(nullable=false, precision=12, scale=2) private BigDecimal net;
    public PayrollItem() {}
    public Long getId(){ return id; } public void setId(Long id){ this.id = id; }
    public PayrollRun getRun(){ return run; } public void setRun(PayrollRun run){ this.run = run; }
    public Employee getEmployee(){ return employee; } public void setEmployee(Employee employee){ this.employee = employee; }
    public java.math.BigDecimal getGross(){ return gross; } public void setGross(java.math.BigDecimal gross){ this.gross = gross; }
    public java.math.BigDecimal getDeductions(){ return deductions; } public void setDeductions(java.math.BigDecimal deductions){ this.deductions = deductions; }
    public java.math.BigDecimal getNet(){ return net; } public void setNet(java.math.BigDecimal net){ this.net = net; }
}
