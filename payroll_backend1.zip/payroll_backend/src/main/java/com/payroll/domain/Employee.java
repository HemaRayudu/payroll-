package com.payroll.domain;
import jakarta.persistence.*;
import java.time.LocalDate;
@Entity @Table(name="employees")
public class Employee {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @OneToOne(optional=false) @JoinColumn(name="user_id", unique=true) private User user;
    @Column(nullable=false) private String firstName;
    @Column(nullable=false) private String lastName;
    private LocalDate dob; private String phone; private String address;
    @ManyToOne @JoinColumn(name="department_id") private Department department;
    @ManyToOne @JoinColumn(name="job_id") private Job job;
    public Employee() {}
    public Long getId(){ return id; } public void setId(Long id){ this.id = id; }
    public User getUser(){ return user; } public void setUser(User user){ this.user = user; }
    public String getFirstName(){ return firstName; } public void setFirstName(String firstName){ this.firstName = firstName; }
    public String getLastName(){ return lastName; } public void setLastName(String lastName){ this.lastName = lastName; }
    public java.time.LocalDate getDob(){ return dob; } public void setDob(java.time.LocalDate dob){ this.dob = dob; }
    public String getPhone(){ return phone; } public void setPhone(String phone){ this.phone = phone; }
    public String getAddress(){ return address; } public void setAddress(String address){ this.address = address; }
    public Department getDepartment(){ return department; } public void setDepartment(Department department){ this.department = department; }
    public Job getJob(){ return job; } public void setJob(Job job){ this.job = job; }
}
