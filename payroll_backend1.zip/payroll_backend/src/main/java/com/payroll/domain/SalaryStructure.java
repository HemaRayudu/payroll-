package com.payroll.domain;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
@Entity @Table(name="salary_structures")
public class SalaryStructure {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional=false) @JoinColumn(name="employee_id") private Employee employee;
    @Column(nullable=false, precision=12, scale=2) private BigDecimal basic;
    @Column(precision=12, scale=2) private BigDecimal hra;
    @Column(precision=12, scale=2) private BigDecimal allowances;
    @Column(precision=12, scale=2) private BigDecimal deductions;
    @Column(nullable=false) private LocalDate effectiveFrom; private LocalDate effectiveTo;
    public SalaryStructure() {}
    public Long getId(){ return id; } public void setId(Long id){ this.id = id; }
    public Employee getEmployee(){ return employee; } public void setEmployee(Employee employee){ this.employee = employee; }
    public BigDecimal getBasic(){ return basic; } public void setBasic(BigDecimal basic){ this.basic = basic; }
    public BigDecimal getHra(){ return hra; } public void setHra(BigDecimal hra){ this.hra = hra; }
    public BigDecimal getAllowances(){ return allowances; } public void setAllowances(BigDecimal allowances){ this.allowances = allowances; }
    public BigDecimal getDeductions(){ return deductions; } public void setDeductions(BigDecimal deductions){ this.deductions = deductions; }
    public LocalDate getEffectiveFrom(){ return effectiveFrom; } public void setEffectiveFrom(LocalDate effectiveFrom){ this.effectiveFrom = effectiveFrom; }
    public LocalDate getEffectiveTo(){ return effectiveTo; } public void setEffectiveTo(LocalDate effectiveTo){ this.effectiveTo = effectiveTo; }
}
