package com.payroll.repository;
import com.payroll.domain.PayrollItem;
import com.payroll.domain.PayrollRun;
import com.payroll.domain.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface PayrollItemRepository extends JpaRepository<PayrollItem, Long> {
    List<PayrollItem> findByRun(PayrollRun run);
    Optional<PayrollItem> findByRunAndEmployee(PayrollRun run, Employee employee);
}
