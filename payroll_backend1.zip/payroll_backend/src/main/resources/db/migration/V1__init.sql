CREATE TABLE IF NOT EXISTS users (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  role VARCHAR(20) NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS departments (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL UNIQUE,
  description VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS jobs (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(100) NOT NULL UNIQUE,
  base_salary DECIMAL(12,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS employees (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL UNIQUE,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  dob DATE,
  phone VARCHAR(30),
  address VARCHAR(255),
  department_id BIGINT,
  job_id BIGINT,
  CONSTRAINT fk_emp_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_emp_dept FOREIGN KEY (department_id) REFERENCES departments(id),
  CONSTRAINT fk_emp_job FOREIGN KEY (job_id) REFERENCES jobs(id)
);

CREATE TABLE IF NOT EXISTS salary_structures (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  employee_id BIGINT NOT NULL,
  basic DECIMAL(12,2) NOT NULL,
  hra DECIMAL(12,2),
  allowances DECIMAL(12,2),
  deductions DECIMAL(12,2),
  effective_from DATE NOT NULL,
  effective_to DATE,
  CONSTRAINT fk_sal_emp FOREIGN KEY (employee_id) REFERENCES employees(id)
);

CREATE TABLE IF NOT EXISTS payroll_runs (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  year INT NOT NULL,
  month INT NOT NULL,
  locked BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS payroll_items (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  run_id BIGINT NOT NULL,
  employee_id BIGINT NOT NULL,
  gross DECIMAL(12,2) NOT NULL,
  deductions DECIMAL(12,2) NOT NULL,
  net DECIMAL(12,2) NOT NULL,
  CONSTRAINT fk_item_run FOREIGN KEY (run_id) REFERENCES payroll_runs(id),
  CONSTRAINT fk_item_emp FOREIGN KEY (employee_id) REFERENCES employees(id),
  CONSTRAINT uk_run_employee UNIQUE (run_id, employee_id)
);

CREATE TABLE IF NOT EXISTS leave_requests (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  employee_id BIGINT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  leave_type VARCHAR(50) NOT NULL,
  status VARCHAR(20) NOT NULL,
  CONSTRAINT fk_leave_emp FOREIGN KEY (employee_id) REFERENCES employees(id)
);
