-- seed admin (password: admin123 bcrypt hash)
INSERT INTO users (username, password, email, role, active) VALUES
('admin', '$2a$10$9f5zL2P/0m7E8yxy3AgZ2O1Xf6V9I6oZbGm4p2v3rN2GvQm9tXH1e', 'admin@company.com', 'ADMIN', true)
ON DUPLICATE KEY UPDATE email=VALUES(email);

INSERT INTO departments (name, description) VALUES
('HR', 'Human Resources'),
('Engineering', 'Engineering & Development')
ON DUPLICATE KEY UPDATE description=VALUES(description);

INSERT INTO jobs (title, base_salary) VALUES
('Software Engineer', 60000.00),
('HR Executive', 40000.00)
ON DUPLICATE KEY UPDATE base_salary=VALUES(base_salary);
