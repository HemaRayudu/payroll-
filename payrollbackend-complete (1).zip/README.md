Payroll Backend — Complete project (JWT + Swagger + H2)
Seeded credentials: admin / admin123 (ROLE_ADMIN)

How to run:
1. JDK 17 and Maven installed.
2. From project root directory (where pom.xml is):
   mvn clean package
   java -jar target/payrollbackend-0.0.1-SNAPSHOT.jar
3. Swagger UI: http://localhost:8080/swagger-ui/index.html
4. H2 Console: http://localhost:8080/h2-console  (JDBC URL: jdbc:h2:mem:payrolldb)

Auth flow:
- POST /api/auth/login  { "username": "...", "password": "..." } -> returns { "token": "..." }
- Use 'Authorize' in Swagger with value: Bearer <token>

Provided endpoints:
- POST /api/auth/login
- GET /api/employees
- POST /api/employees
- GET /api/employees/{id}
- GET /api/payrolls
- POST /api/payrolls?employeeId=1&netPay=5000
- GET /api/payrolls/{id}
- GET /api/hello
