package com.example.payrollbackend.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;

import java.util.List;

@Configuration
public class SwaggerConfig {

  private ApiKey apiKey() {
    return new ApiKey("JWT", "Authorization", "header");
  }

  private SecurityContext securityContext() {
    return SecurityContext.builder()
      .securityReferences(List.of(new SecurityReference("JWT", new AuthorizationScope[] { new AuthorizationScope("global","accessEverything") })))
      .build();
  }

  @Bean
  public Docket api() {
    return new Docket(DocumentationType.OAS_30)
      .securityContexts(List.of(securityContext()))
      .securitySchemes(List.of(apiKey()))
      .select()
      .apis(RequestHandlerSelectors.basePackage("com.example.payrollbackend.controller"))
      .paths(PathSelectors.any())
      .build();
  }
}
