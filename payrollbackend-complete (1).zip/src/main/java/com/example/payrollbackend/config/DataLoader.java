package com.example.payrollbackend.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import com.example.payrollbackend.repository.UserRepository;
import com.example.payrollbackend.repository.EmployeeRepository;
import com.example.payrollbackend.model.User;
import com.example.payrollbackend.model.Employee;

@Configuration
public class DataLoader {

  @Bean
  public CommandLineRunner load(UserRepository userRepo, EmployeeRepository empRepo, PasswordEncoder encoder) {
    return args -> {
      if (!userRepo.existsByUsername("admin")) {
        userRepo.save(new User("admin", encoder.encode("admin123"), "ROLE_ADMIN"));
        System.out.println("Seeded admin/admin123");
      }
      if (empRepo.count() == 0) {
        empRepo.save(new Employee("Alice Smith", "Developer", 60000.0));
        empRepo.save(new Employee("Bob Jones", "QA", 45000.0));
      }
    };
  }
}
