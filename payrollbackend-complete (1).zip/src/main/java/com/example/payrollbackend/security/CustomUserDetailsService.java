package com.example.payrollbackend.security;

import org.springframework.stereotype.Service;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import com.example.payrollbackend.repository.UserRepository;
import com.example.payrollbackend.model.User;

@Service
public class CustomUserDetailsService implements org.springframework.security.core.userdetails.UserDetailsService {

  private final UserRepository repo;
  public CustomUserDetailsService(UserRepository repo) { this.repo = repo; }

  @Override
  public CustomUserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    User u = repo.findByUsername(username).orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));
    return new CustomUserDetails(u);
  }
}
