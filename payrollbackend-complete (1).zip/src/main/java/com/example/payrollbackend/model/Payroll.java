package com.example.payrollbackend.model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "payrolls")
public class Payroll {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(optional = false)
  private Employee employee;

  private Double netPay;

  private LocalDate payDate;

  public Payroll() {}

  public Payroll(Employee employee, Double netPay, LocalDate payDate) {
    this.employee = employee;
    this.netPay = netPay;
    this.payDate = payDate;
  }

  public Long getId() { return id; }
  public void setId(Long id) { this.id = id; }
  public Employee getEmployee() { return employee; }
  public void setEmployee(Employee employee) { this.employee = employee; }
  public Double getNetPay() { return netPay; }
  public void setNetPay(Double netPay) { this.netPay = netPay; }
  public LocalDate getPayDate() { return payDate; }
  public void setPayDate(LocalDate payDate) { this.payDate = payDate; }
}
