package com.example.payrollbackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.payrollbackend.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> { }
