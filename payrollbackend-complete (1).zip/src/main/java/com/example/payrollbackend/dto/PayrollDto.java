package com.example.payrollbackend.dto;

import java.time.LocalDate;
public class PayrollDto {
  private Long id;
  private Long employeeId;
  private Double netPay;
  private LocalDate payDate;
  public PayrollDto() {}
  public Long getId() { return id; }
  public void setId(Long id) { this.id = id; }
  public Long getEmployeeId() { return employeeId; }
  public void setEmployeeId(Long employeeId) { this.employeeId = employeeId; }
  public Double getNetPay() { return netPay; }
  public void setNetPay(Double netPay) { this.netPay = netPay; }
  public LocalDate getPayDate() { return payDate; }
  public void setPayDate(LocalDate payDate) { this.payDate = payDate; }
}
