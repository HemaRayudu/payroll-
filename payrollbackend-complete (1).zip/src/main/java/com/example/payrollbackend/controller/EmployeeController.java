package com.example.payrollbackend.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;
import com.example.payrollbackend.repository.EmployeeRepository;
import com.example.payrollbackend.model.Employee;
import com.example.payrollbackend.dto.EmployeeDto;
import java.util.Optional;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

  private final EmployeeRepository repo;

  public EmployeeController(EmployeeRepository repo) { this.repo = repo; }

  @GetMapping
  public List<EmployeeDto> list() {
    return repo.findAll().stream().map(e -> {
      EmployeeDto d = new EmployeeDto();
      d.setId(e.getId()); d.setName(e.getName()); d.setRole(e.getRole()); d.setSalary(e.getSalary());
      return d;
    }).collect(Collectors.toList());
  }

  @PostMapping
  public EmployeeDto create(@RequestBody EmployeeDto dto) {
    Employee e = new Employee(dto.getName(), dto.getRole(), dto.getSalary());
    Employee saved = repo.save(e);
    dto.setId(saved.getId());
    return dto;
  }

  @GetMapping("/{id}")
  public ResponseEntity<EmployeeDto> get(@PathVariable Long id) {
    Optional<Employee> oe = repo.findById(id);
    if (oe.isEmpty()) return ResponseEntity.notFound().build();
    Employee e = oe.get();
    EmployeeDto d = new EmployeeDto(); d.setId(e.getId()); d.setName(e.getName()); d.setRole(e.getRole()); d.setSalary(e.getSalary());
    return ResponseEntity.ok(d);
  }
}
