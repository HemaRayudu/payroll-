package com.example.payrollbackend.controller;

import org.springframework.web.bind.annotation.*;
import java.util.Map;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import com.example.payrollbackend.security.CustomUserDetails;

@RestController
@RequestMapping("/api/hello")
public class HelloController {
  @GetMapping
  public Map<String, Object> hello(@AuthenticationPrincipal CustomUserDetails user) {
    return Map.of("message", "hello", "user", user.getUsername());
  }
}
