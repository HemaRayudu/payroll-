package com.example.payrollbackend.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import com.example.payrollbackend.dto.AuthRequest;
import com.example.payrollbackend.dto.AuthResponse;
import com.example.payrollbackend.security.CustomUserDetails;
import com.example.payrollbackend.security.JwtTokenUtil;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

  private final AuthenticationManager authManager;
  private final com.example.payrollbackend.security.CustomUserDetailsService userDetailsService;
  private final JwtTokenUtil jwtTokenUtil;

  public AuthController(AuthenticationManager authManager, com.example.payrollbackend.security.CustomUserDetailsService userDetailsService, JwtTokenUtil jwtTokenUtil) {
    this.authManager = authManager;
    this.userDetailsService = userDetailsService;
    this.jwtTokenUtil = jwtTokenUtil;
  }

  @PostMapping("/login")
  public AuthResponse login(@RequestBody AuthRequest req) {
    try {
      authManager.authenticate(new UsernamePasswordAuthenticationToken(req.getUsername(), req.getPassword()));
      CustomUserDetails userDetails = userDetailsService.loadUserByUsername(req.getUsername());
      String token = jwtTokenUtil.generateToken(userDetails);
      return new AuthResponse(token);
    } catch (AuthenticationException ex) {
      throw new RuntimeException("Invalid login credentials");
    }
  }
}
