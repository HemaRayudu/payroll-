package com.example.payrollbackend.controller;

import org.springframework.web.bind.annotation.*;
import com.example.payrollbackend.repository.PayrollRepository;
import com.example.payrollbackend.repository.EmployeeRepository;
import com.example.payrollbackend.model.Payroll;
import com.example.payrollbackend.model.Employee;
import com.example.payrollbackend.dto.PayrollDto;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Optional;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/api/payrolls")
public class PayrollController {

  private final PayrollRepository payrollRepo;
  private final EmployeeRepository empRepo;

  public PayrollController(PayrollRepository payrollRepo, EmployeeRepository empRepo) {
    this.payrollRepo = payrollRepo;
    this.empRepo = empRepo;
  }

  @GetMapping
  public List<PayrollDto> list() {
    return payrollRepo.findAll().stream().map(p -> {
      PayrollDto d = new PayrollDto();
      d.setId(p.getId()); d.setEmployeeId(p.getEmployee().getId()); d.setNetPay(p.getNetPay()); d.setPayDate(p.getPayDate());
      return d;
    }).collect(Collectors.toList());
  }

  @PostMapping
  public ResponseEntity<PayrollDto> create(@RequestParam Long employeeId, @RequestParam Double netPay) {
    Optional<Employee> oe = empRepo.findById(employeeId);
    if (oe.isEmpty()) return ResponseEntity.badRequest().build();
    Payroll p = new Payroll(oe.get(), netPay, LocalDate.now());
    Payroll saved = payrollRepo.save(p);
    PayrollDto d = new PayrollDto(); d.setId(saved.getId()); d.setEmployeeId(saved.getEmployee().getId()); d.setNetPay(saved.getNetPay()); d.setPayDate(saved.getPayDate());
    return ResponseEntity.ok(d);
  }

  @GetMapping("/{id}")
  public ResponseEntity<PayrollDto> get(@PathVariable Long id) {
    Optional<Payroll> op = payrollRepo.findById(id);
    if (op.isEmpty()) return ResponseEntity.notFound().build();
    Payroll p = op.get();
    PayrollDto d = new PayrollDto(); d.setId(p.getId()); d.setEmployeeId(p.getEmployee().getId()); d.setNetPay(p.getNetPay()); d.setPayDate(p.getPayDate());
    return ResponseEntity.ok(d);
  }
}
